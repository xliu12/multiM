multiple mediators with clustered data
================

<!-- badges: start -->
<!-- badges: end -->

Interventional (in)direct effects for multiple mediators with clustered data.

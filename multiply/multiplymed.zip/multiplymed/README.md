multiple mediators
================

<!-- badges: start -->
<!-- badges: end -->

Interventional (in)direct effects with multiple mediators.
